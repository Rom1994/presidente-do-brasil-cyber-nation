# Cyber Nation — compilação Android na nuvem

Este pacote contém o projeto Godot 4.3 e a configuração para gerar um APK de teste usando GitHub Actions.

## 1. Criar o repositório
1. Entre em https://github.com/new
2. Nome: `presidente-do-brasil-cyber-nation`
3. Escolha **Private** (recomendado) ou Public.
4. Não marque README, .gitignore ou licença (o pacote já contém esses arquivos).
5. Toque em **Create repository**.

## 2. Enviar os arquivos
1. Extraia este ZIP no celular ou computador.
2. Abra o repositório recém-criado no GitHub.
3. Use **Add file > Upload files**.
4. Envie o conteúdo da pasta extraída, mantendo a estrutura:
   - `project.godot`
   - `project.godot` e pastas `scenes/` e `scripts/`
   - `export_presets.cfg`
   - `.github/workflows/android-apk.yml`
5. Faça commit na branch `main`.

IMPORTANTE: o caminho `.github/workflows/android-apk.yml` precisa ser mantido exatamente. No celular, se o upload pelo navegador não permitir enviar a pasta oculta `.github`, crie as pastas `.github` e `workflows` no site e adicione o arquivo `android-apk.yml` dentro dela. Não coloque o YAML na raiz.

## 3. Executar a compilação
1. No repositório, abra a aba **Actions**.
2. Se solicitado, habilite GitHub Actions.
3. Selecione **Cyber Nation - APK Android**.
4. Toque em **Run workflow** e confirme.
5. Aguarde o trabalho **Exportar APK de teste** terminar com marca verde.

O workflow também inicia automaticamente a cada commit enviado para `main` ou `master`.

## 4. Baixar e instalar
1. Abra a execução concluída em **Actions**.
2. Na seção **Artifacts**, baixe `CyberNation-Android-APK`.
3. Extraia o ZIP baixado para obter `CyberNation-debug.apk`.
4. Abra o APK no Android e autorize a instalação pelo navegador/gerenciador de arquivos, se o aparelho solicitar.

## Observações
- O artefato é um APK de depuração para teste, não uma versão de publicação na Play Store.
- O artefato fica disponível por 14 dias.
- Este workflow ainda precisa ser validado na primeira execução. Se falhar, abra a etapa vermelha nos Actions e envie um print ou copie as últimas 30 linhas do log.
- Para publicar na Play Store, será necessário configurar assinatura de release e gerar AAB separadamente.
