# PRESIDENTE DO BRASIL: CYBER NATION — Protótipo 0.1

## Requisitos
- Godot Engine 4.3 ou superior (versão Standard).
- Para gerar APK: export templates do Godot e Android SDK/JDK configurados.

## Abrir
1. Extraia o ZIP.
2. Abra Godot.
3. Clique em Importar e selecione `project.godot`.
4. Execute com F6/F5.

## Controles
- PC: WASD ou setas para andar; E ou Espaço para interagir.
- Celular: botões direcionais na tela e botão INTERAGIR.
- Botão SALVAR grava o progresso local.

## O que já funciona
- Cidade futurista desenhada proceduralmente.
- Personagem movimentável.
- Cinco cidadãos NPCs com diálogos.
- Sistema de aproximação e interação.
- Indicadores de popularidade, reputação e influência.
- Primeira missão: conquistar apoio de três moradores.
- Salvamento local.

## Limitações desta versão
Este é um protótipo inicial: ainda não contém arte final em sprites, animações, eleições completas, áudio, menus elaborados ou sistema de governo. A missão concluída libera a candidatura como objetivo narrativo, mas a eleição ainda será implementada na próxima versão.

## Exportar para Android
No Godot:
1. Instale os Export Templates correspondentes à versão do editor.
2. Configure o Android SDK e Java SDK em Editor > Editor Settings > Export > Android.
3. Em Project > Export, adicione Android.
4. Configure package name, por exemplo `com.cybernation.presidientedobrasil`.
5. Exporte APK para teste ou AAB para publicação na Google Play.

O APK não está incluído neste ZIP porque a compilação depende do ambiente Android SDK e das chaves de assinatura do desenvolvedor.
