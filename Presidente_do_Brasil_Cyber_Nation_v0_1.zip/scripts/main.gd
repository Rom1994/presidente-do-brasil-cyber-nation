extends Node2D

# PRESIDENTE DO BRASIL: CYBER NATION - protótipo jogável 0.1
# Controles: WASD/setas ou botões na tela. E/espaço ou botão INTERAGIR.

const WORLD_SIZE := Vector2(1800, 1100)
const SAVE_PATH := "user://cyber_nation_save.cfg"

var player_pos := Vector2(900, 570)
var player_speed := 260.0
var popularity := 18
var reputation := 12
var influence := 5
var campaign_points := 0
var interacted := {}
var message := "2089 | NOVA AURORA: fale com os moradores e construa sua campanha."
var message_time := 7.0
var nearby_npc := -1
var touch_dir := Vector2.ZERO
var campaign_complete := false

var npcs := [
    {"name":"LIA-07", "role":"Mecânica ciborgue", "pos":Vector2(610, 430), "line":"Implantes são caros. Quero tecnologia acessível para todos."},
    {"name":"MARCOS", "role":"Entregador autônomo", "pos":Vector2(1120, 390), "line":"As plataformas controlam nosso trabalho. Precisamos de regras."},
    {"name":"DRA. YARA", "role":"Médica de bairro", "pos":Vector2(770, 790), "line":"A clínica precisa de energia e equipamentos, não de promessas."},
    {"name":"NEXUS-4", "role":"Assistente de IA", "pos":Vector2(1330, 700), "line":"Cidadão, seus dados influenciam a estabilidade do distrito."},
    {"name":"JOÃO 2.0", "role":"Líder comunitário", "pos":Vector2(390, 720), "line":"A corporação quer comprar nosso bairro. Você vai nos defender?"}
]

func _ready() -> void:
    _load_game()
    _build_ui()
    queue_redraw()

func _process(delta: float) -> void:
    var direction := Vector2.ZERO
    direction.x = Input.get_action_strength("ui_right") - Input.get_action_strength("ui_left")
    direction.y = Input.get_action_strength("ui_down") - Input.get_action_strength("ui_up")
    direction += touch_dir
    if direction.length() > 1.0:
        direction = direction.normalized()
    player_pos += direction * player_speed * delta
    player_pos.x = clamp(player_pos.x, 60.0, WORLD_SIZE.x - 60.0)
    player_pos.y = clamp(player_pos.y, 120.0, WORLD_SIZE.y - 60.0)

    nearby_npc = _find_nearest_npc()
    if message_time > 0:
        message_time -= delta
    queue_redraw()

func _unhandled_key_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_E or event.keycode == KEY_SPACE:
            _interact()
        elif event.keycode == KEY_ESCAPE:
            _save_game()

func _draw() -> void:
    var cam := get_viewport_rect().size
    var offset := player_pos - cam / 2.0
    offset.x = clamp(offset.x, 0.0, WORLD_SIZE.x - cam.x)
    offset.y = clamp(offset.y, 0.0, WORLD_SIZE.y - cam.y)

    # A câmera acompanha o jogador; a interface permanece fixa por estar em CanvasLayer.
    draw_set_transform(-offset)

    # Fundo e grade neon
    draw_rect(Rect2(Vector2.ZERO, WORLD_SIZE), Color("#100b25"))
    for x in range(0, int(WORLD_SIZE.x), 80):
        draw_line(Vector2(x, 0), Vector2(x, WORLD_SIZE.y), Color(0.22, 0.12, 0.38, 0.32), 1.0)
    for y in range(0, int(WORLD_SIZE.y), 80):
        draw_line(Vector2(0, y), Vector2(WORLD_SIZE.x, y), Color(0.22, 0.12, 0.38, 0.32), 1.0)

    # Avenidas
    draw_rect(Rect2(0, 500, WORLD_SIZE.x, 150), Color("#24203a"))
    draw_rect(Rect2(820, 0, 150, WORLD_SIZE.y), Color("#24203a"))
    for x in range(0, int(WORLD_SIZE.x), 90):
        draw_line(Vector2(x, 575), Vector2(x + 42, 575), Color("#ff4fd8"), 3.0)
    for y in range(0, int(WORLD_SIZE.y), 90):
        draw_line(Vector2(895, y), Vector2(895, y + 42), Color("#38d9ff"), 3.0)

    # Edifícios e pontos de interesse
    _building(Vector2(160, 170), Vector2(260, 190), "CENTRO CÍVICO", Color("#45206f"))
    _building(Vector2(1120, 130), Vector2(300, 220), "TORRE NEXUS", Color("#173b70"))
    _building(Vector2(150, 850), Vector2(270, 170), "CLÍNICA POPULAR", Color("#55235f"))
    _building(Vector2(1190, 850), Vector2(320, 170), "DISTRITO CORPORATIVO", Color("#34215d"))
    _building(Vector2(620, 170), Vector2(150, 170), "METRÔ", Color("#293e70"))
    _building(Vector2(1010, 760), Vector2(150, 130), "MERCADO", Color("#57285e"))

    # NPCs
    for i in range(npcs.size()):
        var p: Vector2 = npcs[i]["pos"]
        var is_near := i == nearby_npc
        draw_circle(p, 20, Color("#ff4fd8") if is_near else Color("#38d9ff"))
        draw_circle(p, 13, Color("#171126"))
        draw_circle(p + Vector2(0, -4), 7, Color("#f4c9ff"))
        draw_rect(Rect2(p + Vector2(-11, 7), Vector2(22, 16)), Color("#9d5cff"))
        draw_string(ThemeDB.fallback_font, p + Vector2(-42, -29), str(npcs[i]["name"]), HORIZONTAL_ALIGNMENT_CENTER, 84, 14, Color.WHITE)

    # Jogador
    draw_circle(player_pos, 25, Color(0.15, 0.85, 1.0, 0.25))
    draw_circle(player_pos, 17, Color("#ff4fd8"))
    draw_circle(player_pos, 11, Color("#d8f8ff"))
    draw_rect(Rect2(player_pos + Vector2(-10, 10), Vector2(20, 19)), Color("#7438b8"))
    draw_circle(player_pos + Vector2(5, -3), 3, Color("#151020"))

    # Restaura a transformação para não afetar outros desenhos.
    draw_set_transform(Vector2.ZERO)

func _building(pos: Vector2, size: Vector2, label: String, color: Color) -> void:
    draw_rect(Rect2(pos + Vector2(8, 8), size), Color(0, 0, 0, 0.45))
    draw_rect(Rect2(pos, size), color)
    draw_rect(Rect2(pos + Vector2(10, 10), size - Vector2(20, 20)), Color(0.08, 0.06, 0.18))
    for x in range(int(pos.x + 22), int(pos.x + size.x - 15), 34):
        for y in range(int(pos.y + 25), int(pos.y + size.y - 20), 36):
            draw_rect(Rect2(Vector2(x, y), Vector2(13, 18)), Color("#38d9ff"))
    draw_string(ThemeDB.fallback_font, pos + Vector2(10, size.y + 22), label, HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color("#ff8ce8"))

func _find_nearest_npc() -> int:
    var best := -1
    var best_dist := 100.0
    for i in range(npcs.size()):
        var d: float = player_pos.distance_to(npcs[i]["pos"])
        if d < best_dist:
            best_dist = d
            best = i
    return best

func _interact() -> void:
    if nearby_npc < 0:
        _set_message("Chegue mais perto de um morador para conversar.")
        return
    var npc_name: String = npcs[nearby_npc]["name"]
    if interacted.has(npc_name):
        _set_message(npc_name + ": Já conversamos. Continue visitando outros moradores.")
        return
    interacted[npc_name] = true
    campaign_points += 1
    popularity = min(100, popularity + 7)
    reputation = min(100, reputation + 4)
    influence = min(100, influence + 2)
    _set_message(npc_name + " — " + npcs[nearby_npc]["line"] + " (+7 popularidade)")
    if interacted.size() >= 3:
        campaign_complete = true
        _set_message("MISSÃO CONCLUÍDA: você conquistou apoio suficiente para lançar sua candidatura a vereador!")
    _save_game()
    _refresh_ui()

func _set_message(value: String) -> void:
    message = value
    message_time = 8.0
    _refresh_ui()

func _build_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)

    var panel := PanelContainer.new()
    panel.position = Vector2(16, 14)
    panel.size = Vector2(350, 126)
    layer.add_child(panel)
    var v := VBoxContainer.new()
    panel.add_child(v)
    var title := Label.new()
    title.text = "CYBER NATION  |  NOVA AURORA"
    title.add_theme_color_override("font_color", Color("#38d9ff"))
    title.add_theme_font_size_override("font_size", 18)
    v.add_child(title)
    var stats := Label.new()
    stats.name = "Stats"
    stats.text = _stats_text()
    stats.add_theme_color_override("font_color", Color.WHITE)
    v.add_child(stats)
    var objective := Label.new()
    objective.name = "Objective"
    objective.text = "OBJETIVO: converse com 3 moradores."
    objective.add_theme_color_override("font_color", Color("#ff8ce8"))
    v.add_child(objective)

    var msg := Label.new()
    msg.name = "Message"
    msg.position = Vector2(380, 18)
    msg.size = Vector2(650, 92)
    msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    msg.add_theme_color_override("font_color", Color.WHITE)
    msg.add_theme_font_size_override("font_size", 17)
    layer.add_child(msg)

    var interact := Button.new()
    interact.text = "INTERAGIR"
    interact.position = Vector2(1050, 600)
    interact.size = Vector2(190, 76)
    interact.add_theme_color_override("font_color", Color.WHITE)
    interact.add_theme_stylebox_override("normal", _button_style(Color("#842cbd")))
    interact.pressed.connect(_interact)
    layer.add_child(interact)

    var save_btn := Button.new()
    save_btn.text = "SALVAR"
    save_btn.position = Vector2(1090, 18)
    save_btn.size = Vector2(150, 48)
    save_btn.pressed.connect(_save_game)
    layer.add_child(save_btn)

    # Direcional touch
    _add_direction_button(layer, "◀", Vector2(30, 585), Vector2(-1, 0))
    _add_direction_button(layer, "▶", Vector2(150, 585), Vector2(1, 0))
    _add_direction_button(layer, "▲", Vector2(90, 525), Vector2(0, -1))
    _add_direction_button(layer, "▼", Vector2(90, 645), Vector2(0, 1))
    _refresh_ui()

func _add_direction_button(parent: Node, label_text: String, pos: Vector2, dir: Vector2) -> void:
    var b := Button.new()
    b.text = label_text
    b.position = pos
    b.size = Vector2(54, 54)
    b.modulate = Color(0.8, 0.65, 1.0, 0.9)
    parent.add_child(b)
    b.button_down.connect(func(): touch_dir = dir)
    b.button_up.connect(func(): if touch_dir == dir: touch_dir = Vector2.ZERO)

func _button_style(c: Color) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = c
    s.border_color = Color("#38d9ff")
    s.set_border_width_all(2)
    s.set_corner_radius_all(12)
    return s

func _stats_text() -> String:
    return "POPULARIDADE: %d%%   REPUTAÇÃO: %d%%\nINFLUÊNCIA: %d   APOIOS: %d/3" % [popularity, reputation, influence, interacted.size()]

func _refresh_ui() -> void:
    var stats := get_node_or_null("CanvasLayer/PanelContainer/VBoxContainer/Stats")
    # UI é criada dinamicamente; procura por nome em toda a árvore.
    var layer := get_child(0) if get_child_count() > 0 else null
    if layer:
        var panel := layer.get_child(0)
        if panel and panel.get_child_count() > 0:
            var v := panel.get_child(0)
            if v.get_child_count() > 1:
                v.get_child(1).text = _stats_text()
            if v.get_child_count() > 2:
                v.get_child(2).text = "MISSÃO CONCLUÍDA: candidatura liberada!" if campaign_complete else "OBJETIVO: converse com 3 moradores."
        var msg := layer.get_node_or_null("Message")
        if msg:
            msg.text = message if message_time > 0 else "Aproxime-se de um cidadão e toque em INTERAGIR."

func _save_game() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("player", "x", player_pos.x)
    cfg.set_value("player", "y", player_pos.y)
    cfg.set_value("politics", "popularity", popularity)
    cfg.set_value("politics", "reputation", reputation)
    cfg.set_value("politics", "influence", influence)
    cfg.set_value("campaign", "interacted", interacted.keys())
    cfg.set_value("campaign", "complete", campaign_complete)
    cfg.save(SAVE_PATH)
    _set_message("Progresso salvo neste dispositivo.")

func _load_game() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(SAVE_PATH) == OK:
        player_pos = Vector2(cfg.get_value("player", "x", 900.0), cfg.get_value("player", "y", 570.0))
        popularity = int(cfg.get_value("politics", "popularity", 18))
        reputation = int(cfg.get_value("politics", "reputation", 12))
        influence = int(cfg.get_value("politics", "influence", 5))
        var saved_names: Array = cfg.get_value("campaign", "interacted", [])
        for n in saved_names:
            interacted[str(n)] = true
        campaign_complete = bool(cfg.get_value("campaign", "complete", false))
